#include <xc.h>
#include <stdint.h>

#include "pragmas.h"

// These are used to disable/enable UART interrupts before/after
// buffering functions are called from the main thread. This prevents
// critical race conditions that result in corrupt buffer data and hence
// incorrect processing
inline void disable_rxtx(void) {
    PIE1bits.RC1IE = 0;
    PIE1bits.TX1IE = 0;
}
inline void enable_rxtx(void) {
    PIE1bits.RC1IE = 1;
    PIE1bits.TX1IE = 1;
}

/* **** Ring-buffers for incoming and outgoing data **** */
// These buffer functions are modularized to handle both the input and
// output buffers with an input argument.
typedef enum {INBUF = 0, OUTBUF = 1} buf_t;

#define BUFSIZE 1024        /* Static buffer size. Maximum amount of data */
uint8_t inbuf[BUFSIZE];   /* Preallocated buffer for incoming data */
uint8_t outbuf[BUFSIZE];  /* Preallocated buffer for outgoing data  */
uint8_t head[2] = {0, 0}; /* head for pushing, tail for popping */
uint8_t tail[2] = {0, 0};

/* Check if a buffer had data or not */
#pragma interrupt_level 2 // Prevents duplication of function
uint8_t buf_isempty(buf_t buf) {
    return (head[buf] == tail[buf]) ? 1 : 0;
}
/* Place new data in buffer */
#pragma interrupt_level 2 // Prevents duplication of function
void buf_push( uint8_t v, buf_t buf) {
    if (buf == INBUF) inbuf[head[buf]] = v;
    else outbuf[head[buf]] = v;
    head[buf]++;
    if (head[buf] == BUFSIZE) head[buf] = 0;
    // if (head[buf] == tail[buf]) {  }
}
/* Retrieve data from buffer */
#pragma interrupt_level 2 // Prevents duplication of function
uint8_t buf_pop( buf_t buf ) {
    uint8_t v;
    if (buf_isempty(buf)) {
        return 0;
    } else {
        if (buf == INBUF) v = inbuf[tail[buf]];
        else v = outbuf[tail[buf]];
        tail[buf]++;
        if (tail[buf] == BUFSIZE) tail[buf] = 0;
        return v;
    }
}

/* **** ISR functions **** */
void receive_isr() {
    buf_push(RCREG1, INBUF); // Buffer incoming byte
    PIR1bits.RC1IF = 0;      // Acknowledge interrupt
}
void transmit_isr() {
    // If all bytes are transmitted, turn off transmission
    if (buf_isempty(OUTBUF)) {
        while (TXSTA1bits.TRMT == 0) {
            
        }
        TXSTA1bits.TXEN = 0;
        enable_rxtx();
        return;
    }
    if (!buf_isempty(OUTBUF)) {
        TXREG1 = buf_pop(OUTBUF);
    }
    TXSTA1bits.TXEN = 1;
}

void send(uint8_t v) {
    disable_rxtx();
    buf_push(v, OUTBUF);
    TXSTA1bits.TXEN = 1;
    enable_rxtx();
}

int distance = 0, started = 0, speed = 0, running = 1;
int alt_val = 0, alt_counter = 0, altitude = 0;
int adc_val = 0;
int man_activated = 0;
int led_id = 0;
int response4 = 0, response5 = 0, response6 = 0, response7 = 0;
int flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0;

/* **** Initialization functions **** */
void init_ports() { 
    LATA = 0x00; TRISA = 0x00;
    LATB = 0x00; TRISB = 0xF0;
    LATC = 0x00; TRISC = 0x80;
    LATD = 0x00; TRISD = 0x00;
}

// Choose SPBRG from Table 20.3
#define SPBRG_VAL (21)
void init_serial() {
    // We will configure EUSART1 for 112500 baud
    // SYNC = 0, BRGH = 0, BRG16 = 1. Simulator does not seem to work
    // very well with BRGH=1

    TXSTA1bits.TX9 = 0;    // 9th bit
    TXSTA1bits.TXEN = 0;   // Transmission is disabled for the time being
    TXSTA1bits.SYNC = 0;
    TXSTA1bits.BRGH = 1;
    
    RCSTA1bits.SPEN = 1;   // Enable serial port
    RCSTA1bits.RX9 = 0;    // 9th bit
    RCSTA1bits.CREN = 1;   // Continuous reception
    BAUDCON1bits.BRG16 = 0;

    SPBRGH1 = (SPBRG_VAL >> 8) & 0xff;
    SPBRG1 = SPBRG_VAL & 0xff;
}

void init_interrupts() {
    // Enable reception and transmission interrupts
    enable_rxtx();
    INTCON = 0x00;
    INTCONbits.PEIE = 1;
    T0CON = 0x00;
    T0CONbits.T0PS2 = 0;
    T0CONbits.T0PS1 = 1;
    T0CONbits.T0PS0 = 1;
    TMR0H = 0x0B;
    TMR0L = 0xDC;
    
    RCON = 0x00;
    
    INTCONbits.TMR0IE = 1;
    PIR1 = 0x00;
    
    INTCON2 = 0x00;
}

void start_system() {
    INTCONbits.GIE = 1;
}

/* **** Packet task **** */
#define PKT_MAX_SIZE 512 // Maximum packet size. Syntax errors can be large!
#define PKT_HEADER '$'  // Marker for start-of-packet
#define PKT_END '#'     // Marker for end-of-packet

// State machine states for packet reception.
typedef enum {PKT_WAIT_HDR, PKT_GET_BODY, PKT_WAIT_ACK} pkt_state_t;
pkt_state_t pkt_state = PKT_WAIT_HDR;
uint8_t pkt_body[PKT_MAX_SIZE]; // Packet data
uint8_t pkt_bodysize;           // Size of the current packet
// Set to 1 when packet has been received. Must be set to 0 once packet is processed
uint8_t pkt_valid = 0;

/* The packet task is responsible from monitoring the input buffer, identify
 * the start marker 0x00, and retrieve all subsequent bytes until the end marker
 * 0xff is encountered. This packet will then be processed by the calc_task()
 * to parse and execute the arithmetic expression. */
void receive_task() {
    disable_rxtx();
    // Wait until new bytes arrive
    if (!buf_isempty(INBUF)) {
        uint8_t v;
        switch(pkt_state) {
            case PKT_WAIT_HDR:
                v = buf_pop(INBUF);
                if (v == PKT_HEADER) {
                    // Packet header is encountered, retrieve the rest of the packet
                    pkt_state = PKT_GET_BODY;
                    pkt_bodysize = 0;
                }
                break;
            case PKT_GET_BODY:
                v = buf_pop(INBUF);
                if (v == PKT_END) {
                    // End of packet is encountered, signal calc_task())
                    pkt_state = PKT_WAIT_ACK;
                    pkt_valid = 1;
                } else if (v == PKT_HEADER) {
                    // Unexpected packet start. Abort current packet and restart
                    pkt_bodysize = 0;
                } else
                    pkt_body[pkt_bodysize++] = v;
                break;
            case PKT_WAIT_ACK:
                if (pkt_valid == 0) {
                    // Packet processing seems to be finished, continue monitoring
                    pkt_state = PKT_WAIT_HDR;
                }
                break;
        }
    }
    enable_rxtx();
}

/* Output task function */
void output_task() {
    disable_rxtx();
    // Check if there is any buffered output or ongoing transmission
    if (!buf_isempty(OUTBUF)) {
        // If transmission is already ongoing, do nothing,
        // the ISR will send the next char. Otherwise, send the
        // first char and enable transmission
        TXSTA1bits.TXEN = 1;
        // TXREG1 = buf_pop(OUTBUF);
    }
    // TXSTA1bits.TXEN = 1;
    enable_rxtx();
}

void handle_packet() {
    if (started == 0 && pkt_body[0] == 'G' && pkt_body[1] == 'O' && pkt_body[2] == 'O') {
        started = 1;
        T0CONbits.TMR0ON = 1;
        sscanf(pkt_body+3, "%04x", &distance);
    }
    if (pkt_body[0] == 'E' && pkt_body[1] == 'N' && pkt_body[2] == 'D') {
        running = 0;
    }
    if (pkt_body[0] == 'S' && pkt_body[1] == 'P' && pkt_body[2] == 'D') {
        sscanf(pkt_body+3, "%04x", &speed);
    }
    if (pkt_body[0] == 'A' && pkt_body[1] == 'L' && pkt_body[2] == 'T') {
        sscanf(pkt_body+3, "%04x", &alt_val);
        if (alt_val != 0) {
            ADIE = 1;
        } else {
            ADIE = 0;
        }
        alt_counter = 0;
    }
    if (pkt_body[0] == 'M' && pkt_body[1] == 'A' && pkt_body[2] == 'N') {
        sscanf(pkt_body+3, "%02x", &man_activated);
        if (man_activated) {
            alt_counter = 0;
            INTCONbits.RBIE = 1;
        } else {
            INTCONbits.RBIE = 0;
        }
    }
    if (pkt_body[0] == 'L' && pkt_body[1] == 'E' && pkt_body[2] == 'D') {
        sscanf(pkt_body+3, "%02x", &led_id);
        if (led_id == 0) {
            LATAbits.LA0 = 0;
            LATBbits.LB0 = 0;
            LATCbits.LC0 = 0;
            LATDbits.LD0 = 0;
        } else if (led_id == 1) {
            LATDbits.LD0 = 1;
        } else if (led_id == 2) {
            LATCbits.LC0 = 1;
        } else if (led_id == 3) {
            LATBbits.LB0 = 1;
        } else if (led_id == 4) {
            LATAbits.LA0 = 1;
        }
    }
    
}

void init_adcon() {
    TRISH = 0x10;
    LATH = 0x00;
    
    ADCON0 = 0x30;
    ADCON1 = 0x00;
    ADCON2 = 0xAA;
    
    ADRESH = 0x00;
    ADRESL = 0x00;
    
    ADON = 1;
    
    ADIE = 1;
}

void read_adc() {
    adc_val = (ADRESH << 8) + ADRESL;
}

void get_altitude() {
    if (adc_val < 256) {
        altitude = 9000;
    } else if (adc_val < 512) {
        altitude = 10000;
    } else if (adc_val < 768) {
        altitude = 11000;
    } else {
        altitude = 12000;
    }
}

void __interrupt(high_priority) highPriorityISR(void) {
    if (PIR1bits.RC1IF) {
        receive_isr();
    }
    if (PIR1bits.TX1IF) {
        transmit_isr();
    }
    if (INTCONbits.TMR0IF) {
        INTCONbits.TMR0IF = 0;
        TMR0H = 0x0B;
        TMR0L = 0xDC;
        
        int sent = 0;
        
        distance -= speed;
        
        GODONE = 1;
        
        if (!man_activated) {
            alt_counter += 100;
            if (alt_val != 0 && alt_counter == alt_val) {
                alt_counter = 0;
                char msg[] = "$ALT0000#";
                sprintf(msg+4, "%04x", altitude);
                msg[8] = '#';
                for (int i = 0; i < 9; ++i) {
                    send(msg[i]);
                }
                sent = 1;
            }
        }
        if (man_activated) {
            if (response4) {
                response4 = 0;
                char msg[] = "$PRS04#";
                for (int i = 0; i < 7; ++i) {
                    send(msg[i]);
                }
                sent = 1;
//                LATA = 0x02;
            }
            if (response5) {
                response5 = 0;
                char msg[] = "$PRS05#";
                for (int i = 0; i < 7; ++i) {
                    send(msg[i]);
                }
                sent = 1;
//                LATA = 0x04;
            }
            if (response6) {
                response6 = 0;
                char msg[] = "$PRS06#";
                for (int i = 0; i < 7; ++i) {
                    send(msg[i]);
                }
                sent = 1;
//                LATA = 0x08;
            }
            if (response7) {
                response7 = 0;
                char msg[] = "$PRS07#";
                for (int i = 0; i < 7; ++i) {
                    send(msg[i]);
                }
                sent = 1;
//                LATA = 0x10;
            }
        }
        
        if (!sent) {
            char msg[] = "$DST0000#";
            sprintf(msg+4, "%04x", distance);
            msg[8] = '#';
            for (int i = 0; i < 9; ++i) {
                send(msg[i]);
            }
        }
    }
    if (PIR1bits.ADIF) {
        PIR1bits.ADIF = 0;
        read_adc();
        get_altitude();
    }
    if (INTCONbits.RBIE && INTCONbits.RBIF) {
        __delay_ms(1.31);
        PORTBbits.RB7;
        PORTBbits.RB6;
        PORTBbits.RB5;
        PORTBbits.RB4;
        
//        LATA = LATA + 1;
//        LATA = PORTB;
//        LATD = PORTB;
        
        if (flag1 == 0 && led_id == 1 && !PORTBbits.RB4) {
            flag1 = 1;
        }
        if (flag1 == 1 && led_id == 1 && PORTBbits.RB4) {
            flag1 = 0;
            response4 = 1;
        }
        
        if (flag2 == 0 && led_id == 2 && !PORTBbits.RB5) {
            flag2 = 1;
        }
        if (flag2 == 1 && led_id == 2 && PORTBbits.RB5) {
            flag2 = 0;
            response5 = 1;
        }
        
        if (flag3 == 0 && led_id == 3 && !PORTBbits.RB6) {
            flag3 = 1;
        }
        if (flag3 == 1 && led_id == 3 && PORTBbits.RB6) {
            flag3 = 0;
            response6 = 1;
        }
        
        if (flag4 == 0 && led_id == 4 && !PORTBbits.RB7) {
            flag4 = 1;
        }
        if (flag4 == 1 && led_id == 4 && PORTBbits.RB7) {
            flag4 = 0;
            response7 = 1;
        }
        INTCONbits.RBIF = 0;
    }
}

void main(void) {
    int x = PORTB;
    init_ports();
    init_serial();
    init_interrupts();
    init_adcon();
    start_system();
    
    while (running) {
        receive_task();
        if (pkt_valid) {
            pkt_valid = 0;
            handle_packet();
        }
        if (started) {
            output_task();
        }
    }
}
