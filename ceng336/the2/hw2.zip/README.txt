A0 -> G0
A1 -> G4
A2 -> G2
A3 -> G3

RB5 -> RB7
RB6 -> RB6
