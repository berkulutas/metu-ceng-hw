// ============================ //
// Do not edit this part!!!!    //
// ============================ //
// 0x300001 - CONFIG1H
#pragma config OSC = HSPLL      // Oscillator Selection bits (HS oscillator,
                                // PLL enabled (Clock Frequency = 4 x FOSC1))
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit
                                // (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit
                                // (Oscillator Switchover mode disabled)
// 0x300002 - CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bits (Brown-out
                                // Reset disabled in hardware and software)
// 0x300003 - CONFIG1H
#pragma config WDT = OFF        // Watchdog Timer Enable bit
                                // (WDT disabled (control is placed on the SWDTEN bit))
// 0x300004 - CONFIG3L
// 0x300005 - CONFIG3H
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit
                                // (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled;
                                // RE3 input pin disabled)
// 0x300006 - CONFIG4L
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply
                                // ICSP disabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit
                                // (Instruction set extension and Indexed
                                // Addressing mode disabled (Legacy mode))

#pragma config DEBUG = OFF      // Disable In-Circuit Debugger

#define KHZ 1000UL
#define MHZ (KHZ * KHZ)
#define _XTAL_FREQ (40UL * MHZ)

// ============================ //
//             End              //
// ============================ //

#include <xc.h>

// ============================ //
//        DEFINITIONS           //
// ============================ //

// You can write struct definitions here...

// ============================ //
//          GLOBALS             //
// ============================ //

int piece = 0; // 0 -> dot, 1 -> square, 2 -> L
int active_row = 0, active_col = 0;
int portc = 0, portd = 0, porte = 0, portf = 0;
int count = 0;
int submitted = 0;
int blank = 0;
int fall_counter = 0;
int on = 1;
int left = 0, right = 0, up = 0, down = 0;
int flag = 0, flag2 = 0;

// You can write globals definitions here...

// ============================ //
//          FUNCTIONS           //
// ============================ //

// You can write function definitions here...

// ============================ //
//   INTERRUPT SERVICE ROUTINE  //
// ============================ //
__interrupt(high_priority)
void HandleInterrupt() {
    if(INTCONbits.TMR0IF) {
        INTCONbits.TMR0IF = 0;
        TMR0H = 0x67; // 26474
        TMR0L = 0x6A; // prescaler = 64
        
        on = !on;
        
        fall_counter++;
        if (fall_counter == 8) {
            fall_counter = 0;
            if (piece == 0) {
                if (active_row < 7) {
                    active_row++;
                }
            } else if (piece == 1) {
                if (active_row < 6) {
                    active_row++;
                }
            } else {
                if (active_row < 6) {
                    active_row++;
                }
            }
        }
    }
    
    if (INTCONbits.RBIF) {
        __delay_ms(1);
        INTCONbits.RBIF = 0;
        if (flag == 0 && (PORTB & (1 << 6))) {
            flag = 1;
            if (piece == 0) { // dot piece
                if (active_col == 0) {
                    if (!(portc & (1 << active_row))) {
                        count += 1;
                        submitted = 1;
                        portc |= (1 << active_row);
                    }
                } else if (active_col == 1) {
                    if (!(portd & (1 << active_row))) {
                        count += 1;
                        submitted = 1;
                        portd |= (1 << active_row);
                    }
                } else if (active_col == 2) {
                    if (!(porte & (1 << active_row))) {
                        count += 1;
                        submitted = 1;
                        porte |= (1 << active_row);
                    } 
                } else {
                    if (!(portf & (1 << active_row))) {
                        count += 1;
                        submitted = 1;
                        portf |= (1 << active_row);
                    }
                }
            } else if (piece == 1) { // square
                if (active_col == 0) {
                    if (!(portc & (1 << active_row)) && !(portc & (1 << (active_row + 1))) && !(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1)))) {
                        count += 4;
                        submitted = 1;
                        portc |= (1 << active_row);
                        portc |= (1 << (active_row + 1));
                        portd |= (1 << active_row);
                        portd |= (1 << (active_row + 1));
                    }
                } else if (active_col == 1) {
                    if (!(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1))) && !(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1)))) {
                        count += 4;
                        submitted = 1;
                        portd |= (1 << active_row);
                        portd |= (1 << (active_row + 1));
                        porte |= (1 << active_row);
                        porte |= (1 << (active_row + 1));
                    }
                } else if (active_col == 2) {
                    if (!(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1))) && !(portf & (1 << active_row)) && !(portf & (1 << (active_row + 1)))) {
                        count += 4;
                        submitted = 1;
                        porte |= (1 << active_row);
                        porte |= (1 << (active_row + 1));
                        portf |= (1 << active_row);
                        portf |= (1 << (active_row + 1));
                    } 
                }
            } else { // l piece
                if (active_col == 0) {
                    if (blank == 0) {
                        if (!(portc & (1 << active_row)) && !(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portc |= 1 << active_row;
                            portd |= 1 << active_row;
                            portd |= 1 << (active_row + 1);
                        }
                    } else if (blank == 1) {
                        if (!(portc & (1 << (active_row + 1))) && !(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portc |= 1 << (active_row + 1);
                            portd |= 1 << active_row;
                            portd |= 1 << (active_row + 1);
                        }                    
                    } else if (blank == 2) {
                        if (!(portc & (1 << active_row)) && !(portc & (1 << (active_row + 1))) && !(portd & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portc |= 1 << active_row;
                            portc |= 1 << (active_row + 1);
                            portd |= 1 << (active_row + 1);
                    }
                    } else {
                        if (!(portc & (1 << active_row)) && !(portc & (1 << (active_row + 1))) && !(portd & (1 << (active_row)))) {
                            count += 3;
                            submitted = 1;
                            portc |= 1 << active_row;
                            portc |= 1 << (active_row + 1);
                            portd |= 1 << (active_row);
                        }
                    }
                } else if (active_col == 1) {
                    if (blank == 0) {
                        if (!(portd & (1 << active_row)) && !(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portd |= 1 << active_row;
                            porte |= 1 << active_row;
                            porte |= 1 << (active_row + 1);
                        }
                    } else if (blank == 1) {
                        if (!(portd & (1 << (active_row + 1))) && !(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portd |= 1 << (active_row + 1);
                            porte |= 1 << active_row;
                            porte |= 1 << (active_row + 1);
                        }                    
                    } else if (blank == 2) {
                        if (!(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1))) && !(porte & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            portd |= 1 << active_row;
                            portd |= 1 << (active_row + 1);
                            porte |= 1 << (active_row + 1);
                        }
                    } else {
                        if (!(portd & (1 << active_row)) && !(portd & (1 << (active_row + 1))) && !(porte & (1 << (active_row)))) {
                            count += 3;
                            submitted = 1;
                            portd |= 1 << active_row;
                            portd |= 1 << (active_row + 1);
                            porte |= 1 << (active_row);
                        }
                    }
                } else if (active_col == 2) {
                    if (blank == 0) {
                        if (!(porte & (1 << active_row)) && !(portf & (1 << active_row)) && !(portf & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            porte |= 1 << active_row;
                            portf |= 1 << active_row;
                            portf |= 1 << (active_row + 1);
                        }
                    } else if (blank == 1) {
                        if (!(porte & (1 << (active_row + 1))) && !(portf & (1 << active_row)) && !(portf & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            porte |= 1 << (active_row + 1);
                            portf |= 1 << active_row;
                            portf |= 1 << (active_row + 1);
                        }                    
                    } else if (blank == 2) {
                        if (!(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1))) && !(portf & (1 << (active_row + 1)))) {
                            count += 3;
                            submitted = 1;
                            porte |= 1 << active_row;
                            porte |= 1 << (active_row + 1);
                            portf |= 1 << (active_row + 1);
                        }
                    } else {
                        if (!(porte & (1 << active_row)) && !(porte & (1 << (active_row + 1))) && !(portf & (1 << (active_row)))) {
                            count += 3;
                            submitted = 1;
                            porte |= 1 << active_row;
                            porte |= 1 << (active_row + 1);
                            portf |= 1 << (active_row);
                        }
                    }
                }
            }
        }
        if (!(PORTB & (1 << 6))) {
            flag = 0;
        }
        if (flag2 == 0 && (PORTB & (1 << 7))) {
            flag2 = 1;
            if (piece == 2) {
                blank = (blank + 1) % 4;
            }
        }
        if (!(PORTB & (1 << 7))) {
            flag2 = 0;
        }
    }
}

void Init() {
    LATG = 0x00; TRISG = 0x1D;
    
    LATC = 0x00; TRISC = 0x00;
    LATD = 0x00; TRISD = 0x00;
    LATE = 0x00; TRISE = 0x00;
    LATF = 0x00; TRISF = 0x00;
    
    LATB = 0x00; TRISB = 0xC0;
    
    LATH = 0x00; TRISH = 0x00;
    LATJ = 0x00; TRISJ = 0x00;
}

void InitInterrupts() {
    T0CON = 0x00;
    T0CONbits.TMR0ON = 1;
    T0CONbits.T0PS2 = 1;
    T0CONbits.T0PS1 = 0;
    T0CONbits.T0PS0 = 1;
    TMR0H = 0x67; // 26474
    TMR0L = 0x6A; // prescaler = 64
    
    RCON = 0x00;
    RCONbits.IPEN = 0;
    
    INTCON = 0x00;
    INTCONbits.TMR0IE = 1;
    INTCONbits.RBIE = 1;
    INTCONbits.PEIE = 1;
    
}

void display(int number) {
    LATH = 1 << 0;
    LATJ = 0x3F;
    __delay_ms(1);
    LATH = 1 << 1;
    LATJ = 0x3F;
    __delay_ms(1);
    LATH = 1 << 3;
    switch (number % 10) {
        case 0:
            LATJ = 0x3F;
            break;
        case 1:
            LATJ = 0x06;
            break;
        case 2:
            LATJ = 0x5B;
            break;
        case 3:
            LATJ = 0x4F;
            break;
        case 4:
            LATJ = 0x66;
            break;
        case 5:
            LATJ = 0x6D;
            break;
        case 6:
            LATJ = 0x7D;
            break;
        case 7:
            LATJ = 0x07;
            break;
        case 8:
            LATJ = 0x7F;
            break;
        case 9:
            LATJ = 0x6F;
            break;
    }
    number /= 10;
    __delay_ms(1);
    LATH = 1 << 2;
    switch (number % 10) {
        case 0:
            LATJ = 0x3F;
            break;
        case 1:
            LATJ = 0x06;
            break;
        case 2:
            LATJ = 0x5B;
            break;
        case 3:
            LATJ = 0x4F;
            break;
        case 4:
            LATJ = 0x66;
            break;
        case 5:
            LATJ = 0x6D;
            break;
        case 6:
            LATJ = 0x7D;
            break;
        case 7:
            LATJ = 0x07;
            break;
        case 8:
            LATJ = 0x7F;
            break;
        case 9:
            LATJ = 0x6F;
            break;
    }
    __delay_ms(1);
}

void display_piece() {
    if (piece == 0) { // dot piece
        if (active_col == 0) { 
            if (on) {    
                LATC |= 1 << active_row;
            } else {
                LATC &= ~(1 << active_row);
            }
        } else if (active_col == 1) {
            if (on) {    
                LATD |= 1 << active_row;
            } else {
                LATD &= ~(1 << active_row);
            }
        } else if (active_col == 2) {
            if (on) {    
                LATE |= 1 << active_row;
            } else {
                LATE &= ~(1 << active_row);
            }
        } else {
            if (on) {    
                LATF |= 1 << active_row;
            } else {
                LATF &= ~(1 << active_row);
            }
        }
    } else if (piece == 1) { // square piece 
        if (active_col == 0) {
            if (on) {    
                LATC |= 1 << active_row;
                LATC |= 1 << (active_row + 1);
                LATD |= 1 << active_row;
                LATD |= 1 << (active_row + 1);
            } else {
                LATC &= ~(1 << active_row);
                LATC &= ~(1 << (active_row + 1));
                LATD &= ~(1 << active_row);
                LATD &= ~(1 << (active_row + 1));
            }
        } else if (active_col == 1) {
            if (on) {    
                LATD |= 1 << active_row;
                LATD |= 1 << (active_row + 1);
                LATE |= 1 << active_row;
                LATE |= 1 << (active_row + 1);
            } else {
                LATD &= ~(1 << active_row);
                LATD &= ~(1 << (active_row + 1));
                LATE &= ~(1 << active_row);
                LATE &= ~(1 << (active_row + 1));
            }
        } else if (active_col == 2) {
            if (on) {    
                LATE |= 1 << active_row;
                LATE |= 1 << (active_row + 1);
                LATF |= 1 << active_row;
                LATF |= 1 << (active_row + 1);
            } else {
                LATE &= ~(1 << active_row);
                LATE &= ~(1 << (active_row + 1));
                LATF &= ~(1 << active_row);
                LATF &= ~(1 << (active_row + 1));
            }
        }
    } else { // L PIECE
        if (active_col == 0) {
            if (on) {
                if (blank != 1) {
                    LATC |= 1 << active_row;
                }
                if (blank != 0) {
                    LATC |= 1 << (active_row + 1);
                }
                if (blank != 2) {
                    LATD |= 1 << active_row;
                }
                if (blank != 3) {
                    LATD |= 1 << (active_row + 1);
                }
            } else {
                if (blank != 1) {
                    LATC &= ~(1 << active_row);
                }
                if (blank != 0) {
                    LATC &= ~(1 << (active_row + 1));
                } 
                if (blank != 2) {
                    LATD &= ~(1 << active_row);
                }
                if (blank != 3) {
                    LATD &= ~(1 << (active_row + 1));
                }
            }
        } else if (active_col == 1) {
            if (on) {    
                if (blank != 1) {
                    LATD |= 1 << active_row;
                }
                if (blank != 0) {
                    LATD |= 1 << (active_row + 1);
                }
                if (blank != 2) {
                    LATE |= 1 << active_row;
                }
                if (blank != 3) {
                    LATE |= 1 << (active_row + 1);
                }
            } else {
                if (blank != 1) {
                    LATD &= ~(1 << active_row);
                }
                if (blank != 0) {
                    LATD &= ~(1 << (active_row + 1));
                } 
                if (blank != 2) {
                    LATE &= ~(1 << active_row);
                }
                if (blank != 3) {
                    LATE &= ~(1 << (active_row + 1));
                }
            }
        } else if (active_col == 2) {
            if (on) {    
                if (blank != 1) {
                    LATE |= 1 << active_row;
                }
                if (blank != 0) {
                    LATE |= 1 << (active_row + 1);
                }
                if (blank != 2) {
                    LATF |= 1 << active_row;
                }
                if (blank != 3) {
                    LATF |= 1 << (active_row + 1);
                }
            } else {
                if (blank != 1) {
                    LATE &= ~(1 << active_row);
                }
                if (blank != 0) {
                    LATE &= ~(1 << (active_row + 1));
                } 
                if (blank != 2) {
                    LATF &= ~(1 << active_row);
                }
                if (blank != 3) {
                    LATF &= ~(1 << (active_row + 1));
                }
            }
        }
    }
}

void display_submitted() {
    PORTC = portc;
    PORTD = portd;
    PORTE = porte;
    PORTF = portf;
}

// ============================ //
//            MAIN              //
// ============================ //
void main() {
    Init();
    InitInterrupts();
    __delay_ms(1000);
    INTCONbits.GIE = 1;
    
    while (1) {
        submitted = 0;
        active_row = 0;
        active_col = 0;
        blank = 0;
        while (!submitted) {
            display(count);
            display_submitted();
            display_piece();
            
            if (right == 0 && (PORTG & (1 << 0))) { // right
                if (piece == 0) {
                    if (active_col < 3) {
                        active_col++;
                    }
                } else if (piece == 1) {
                    if (active_col < 2) {
                        active_col++;
                    }
                } else {
                    if (active_col < 2) {
                        active_col++;
                    }
                }
                right = 1;
            }
            if (!(PORTG & (1 << 0))) {
                right = 0;
            }
            if (up == 0 && (PORTG & (1 << 4))) { // up
                if (active_row > 0) {
                    --active_row;
                }
                up = 1;
            }
            if (!(PORTG & (1 << 4))) {
                up = 0;
            }
            if (down == 0 && (PORTG & (1 << 2))) { // down
                if (piece == 0) {
                    if (active_row < 7) {
                        active_row++;
                    }
                } else if (piece == 1) {
                    if (active_row < 6) {
                        active_row++;
                    }
                } else {
                    if (active_row < 6) {
                        active_row++;
                    }
                }
                down = 1;
            }
            if (!(PORTG & (1 << 2))) {
                down = 0;
            }
            if (left == 0 && (PORTG & (1 << 3))) { // left
                if (active_col > 0) {
                    active_col--;
                }
                left = 1;
            }
            if (!(PORTG & (1 << 3))) {
                left = 0;
            }
        }
        piece = (piece + 1) % 3;
        
        if (count == 32) {
            portc = 0;
            portd = 0;
            porte = 0;
            portf = 0;
            count = 0;
            LATC = 0x00;
            LATD = 0x00;
            LATE = 0x00;
            LATF = 0x00;
            piece = 0;
            fall_counter = 0;
            on = 1;
            left = 0;
            right = 0;
            up = 0;
            down = 0;
            flag = 0;
            flag2 = 0;
        }
    }
}
