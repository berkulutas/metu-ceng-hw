#include "BinaryHeap.h"
#include "MeshGraph.h"
#include "ObjLoader.h"

int main(int argv, const char* argc[])
{
    // You can use to test your code here
}